Bonjour,

Voici le projet du groupe Thomas Lerchundi, Julien Tastet, Benoît Zenker(groupe B'').

Vous trouverez dans l'archive:
* Un dossier contenant le rapport et ses pièces jointes.
* Un dossier contenant le code du jeu à compiler grâce au makefile.
* Un exécutable du jeu.
