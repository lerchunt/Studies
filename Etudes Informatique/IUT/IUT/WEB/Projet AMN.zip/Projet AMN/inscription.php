<!DOCTYPE html>
  <head>
    <meta charset="utf-8">
    <title>Inscription</title>
	<link rel="stylesheet" type="text/css" href="style.css">
  </head>

<body>
<h1> Bienvenue, merci de vous etre inscrit:</h1>
<?php 
    // Connexion odbc    
    $host = "Classique";
    $user = "ETD";
    $password = "ETD";
	$nom =  $_REQUEST["nom"];
	$prenom = $_REQUEST["prenom"];
	$login = $_REQUEST["login"];
	$mdp =  $_REQUEST["pswd"];
    $conn = odbc_connect($host,$user,$password,SQL_CUR_USE_ODBC) or die ("rat�");
    // Acc�s � la table
    $result = odbc_exec($conn,"insert into Abonn� (Nom_Abonn�,Pr�nom_Abonn�,Login,Password) values ('" .$nom."', '".$prenom. "', '" .$login."', '".$mdp."')");
    odbc_close($conn);
?>
	<p id="bouton"><a href="Index.html">Accueil</a></p>
</body>

</html>