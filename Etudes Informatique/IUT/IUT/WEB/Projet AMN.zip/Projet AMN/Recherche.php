<?php
	session_start();
    if (isset($_SESSION["NOM_USER"])) 
    {
	echo "Bonjour ".$_SESSION["NOM_USER"];
    }
    else
    {
	echo "Veuillez vous connecter pour acc�der � cette page.";
	$url = $_SERVER["REQUEST_URI"];
	header("Location: Connexion.php?url=".$url);
    }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Recherche</title>
	<link rel="stylesheet" type="text/css" href="style.css">
  </head>
<body>
<h1>
	Par quels crit&egraveres souhaitez vous effectuer votre recherche?
</h1>
	<ul>
        <li><a href="#fakelink">Par titre</a></li>
        <li><a href="#fakelink">Par compositeur</a>
			<ul>
				<li><a href="#fakelink">son nom</a></li>
				<li><a href="#fakelink">sa nationalit&eacute</a></li>
			</ul>
        </li>
		<li><a href="Musicien.html">Par Musicien</a></li>
    </ul>
	<p id="bouton"><a href="Index.html"> Accueil</a> </p>
	
</body>