<?php
    session_start();
    $url = $_REQUEST["url"];
    session_destroy();
    header("Location: ".$url);
?>
<!DOCTYPE html>
  <head>
    <meta charset="utf-8">
    <title>Inscription</title>
	<link rel="stylesheet" type="text/css" href="style.css">
  </head>
	<body>
		
		<h1> Vous etes maintenant deconnecte </h1>
			<p id="bouton"><a href="Index.html">Accueil</a></p>
	</body>
</html>