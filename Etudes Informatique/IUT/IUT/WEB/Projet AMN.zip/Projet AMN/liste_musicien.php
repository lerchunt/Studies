<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Liste des musiciens</title>
    <meta name="description" content="Flat UI Kit Free is a Twitter Bootstrap Framework design and Theme, this responsive framework includes a PSD and HTML version."/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Loading Bootstrap -->
    <link href="Flat-UI-master/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Loading Flat UI -->
    <link href="Flat-UI-master/css/flat-ui.css" rel="stylesheet">
    <link href="Flat-UI-master/css/demo.css" rel="stylesheet">

    <!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
    <!--[if lt IE 9]>
      <script src="Flat-UI-master/js/html5shiv.js"></script>
    <![endif]-->
  </head>
  	<script type="text/javascript">
     var requeteAjax;
     function connect(page) {
        requeteAjax = new XMLHttpRequest();
        if (requeteAjax != null) {
           requeteAjax.open("GET", page, true);
           requeteAjax.onreadystatechange = handler;
           requeteAjax.send();
        }
        else {
           window.alert("Pas de support AJAX (XMLHTTP)");
        } 
    }
    function handler() {
      if (requeteAjax.readyState == 4 /* complete */) {
         if (requeteAjax.status == 200) {
         // fonction utilisateur
            display()
         }
      }
    } 
    function call(lettre) {
       var page = "liste_musicien_morceaux.php?initiale=";
       connect(page + lettre);
    }
    function display() {
       document.write(requeteAjax.responseText);
    } 
	</script>
  <body>
	<div class="container">
<?php 
    // Connexion odbc    
    $host = "Classique";
    $user = "ETD";
    $password = "ETD";
	$variable = $_GET["initiale"];
    $conn = odbc_connect($host,$user,$password,SQL_CUR_USE_ODBC) or die ("rat�");
    // Acc�s � la table
    $result = odbc_exec($conn,"Select Nom_Musicien from Musicien Where Nom_Musicien Like '$variable%' Order by Nom_Musicien");
    // boucle de lecture
    while (odbc_fetch_row($result)) {
		$nom = odbc_result($result,1);
		echo "<a href=liste_musicien_morceaux.php?aut=$nom>$nom</a> <br/>";
	}
	odbc_close($conn);
?>
	</div>
</body>