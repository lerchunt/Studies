<?php
    $Password = $_REQUEST["Password"];
    $Login=$_REQUEST["Login"];
    $url=$_REQUEST["url"];
    // recherche si l'utilisateur est enregistr� et poss�de le bon mot de passe
    $host = "Classique";
    $user = "ETD";
    $password = "ETD"; 
    $conn = odbc_connect($host, $user, $password, SQL_CUR_USE_ODBC) or die ("rat�");
    $query = "Select * from Abonn� where Login ='";
    $query = $query.$Login;
    $query = $query."' and Password ='".$Password."'";
    $result = odbc_exec($conn,$query);
    if ($row = odbc_result($result,1)) {//utilisateur enregistr� avec mot de passe correct
	session_start();
	$_SESSION["NOM_USER"]= odbc_result($result,3);
	odbc_close($conn);
	header("Location: ".$url);
    }
    else
    {//Mot de passe (et/ou login) incorrect : rejet de l'utilisateur
	header("Location: connexion.php?url=".$url);
    }
?>

