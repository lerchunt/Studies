<!DOCTYPE html>
  <head>
    <meta charset="utf-8">
    <title>Connexion</title>
	<link rel="stylesheet" type="text/css" href="style.css">
  </head>
<html>
	<body>  
			
				<form method="post" action="Traite_Connexion.php?url=Protection.php">
				<label>Login : </label><input name="Login" type="text" placeholder="Rentrez votre pseudo"/><br/>
				<label>Mot de passe : </label><input name="Password" type="password" placeholder="Tapez votre mot de passe"/><br/>
				<input name="Connect" type="submit" value="Connecter" />
				</form> <br/>
			
								<h3>Pas encore inscrit? Inscrivez vous!</h3>
								<p id="bouton"><a href="inscription.html">Inscription</a></p>
			
	</body>
</html>