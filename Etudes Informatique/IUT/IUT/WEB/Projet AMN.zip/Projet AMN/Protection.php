<?php
	session_start();
    if (isset($_SESSION["NOM_USER"])) 
    {
	echo "Bonjour ".$_SESSION["NOM_USER"];
    }
    else
    {
	echo "Veuillez vous connecter pour accéder à cette page.";
	$url = $_SERVER["REQUEST_URI"];
	header("Location: Connexion.php?url=".$url);
    }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Connexion</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
    <body>
	
		<h1> Vous avez pu vous connecter</h1>
		<p>
			Vous etes desormais autorise a naviguer sur toutes les pages du site
		</p>
		
			<p>  
				
				<p id="bouton"><a href="deconnexion.php">Deconnexion</a></p>
			</p>
		
		<p id="bouton"><a href="Index.html">Accueil</a></p> <br/>
	</body>
</html>