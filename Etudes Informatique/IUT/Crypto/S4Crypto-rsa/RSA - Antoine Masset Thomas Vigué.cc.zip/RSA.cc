//~ g++ -c RSA.cc
//~ g++ -o RSA RSA.o 

#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <ctime>

using namespace std;

long phi(long p, long q)
{
	return (p-1) * (q-1);
}

long bezout(long e, long phi)
{
	// Ce programme ne fonctionne qu'avec des entiers naturels
	// demande les données à l'utilisateur et convertit les chaînes de caractères en entiers
	long a = e;
	long b = phi;
	 
	// On sauvegarde les valeurs de a et b.
	long a0 = a;
	long b0 = b;
	 
	// Initialisations. On laisse invariant p*a0 + q*b0 = a et  r*a0 + s*b0 = b.
	long p = 1, q = 0;
	long r = 0, s = 1;
	 
	// La boucle principale:
	while (b != 0) { 
	  long c = a % b;
	  long quotient = a / b;  //Javascript n'a pas d'opération de division entière.
	  a = b;
	  b = c;
	  long nouveau_r = p - quotient * r; long nouveau_s = q - quotient * s;
	  p = r; q = s;
	  r = nouveau_r; s = nouveau_s;
	}
	 
	// Affiche le résultat.
	 
	cout << "pgcd(" << a0 << "," << b0 << ")=" << p << "*" << a0 << "+(" << q << ")*" << b0 << "=" << a << endl;
	return p;
}

long pgcd(long a, long b)
{	 
	// On sauvegarde les valeurs de a et b.
	long a0 = a;
	long b0 = b;
	 
	// Initialisations. On laisse invariant p*a0 + q*b0 = a et  r*a0 + s*b0 = b.
	long p = 1, q = 0;
	long r = 0, s = 1;
	 
	// La boucle principale:
	while (b != 0) { 
	  long c = a % b;
	  long quotient = a / b;  //Javascript n'a pas d'opération de division entière.
	  a = b;
	  b = c;
	  long nouveau_r = p - quotient * r; long nouveau_s = q - quotient * s;
	  p = r; q = s;
	  r = nouveau_r; s = nouveau_s;
	}
	 
	// Affiche le résultat.
	 
	//cout << "pgcd(" << a0 << "," << b0 << ")=" << p << "*" << a0 << "+(" << q << ")*" << b0 << "=" << a << endl;
	return a;
}

long puissance(long a, long e, long n)
{
	long p;

	for (p = 1; e > 0; e = e / 2)
	{
		if (e % 2 != 0)
			p = (p * a) % n;
		a = (a * a) % n;
	}
	return p;
}


int rabin(long a, long n) {
	long p, e, m;
	int i, k;

	e = m = n - 1;
	for (k = 0; e % 2 == 0; k++)
		e = e / 2;

	p = puissance (a, e, n);
	if (p == 1) return 1;

	for (i = 0; i < k; i++)
	{
		if (p == m) return 1;
		if (p == 1) return 0;
		p = (p * p) % n;
	}

	return 0;
}

int premier(long n)
{
	long d;
  
	if (n % 2 == 0)
		return (n == 2);
	for (d = 3; d * d <= n; d = d + 2)
		if (n % d == 0)
			return 0;
	return 1;
}

void diffieHellman()
{
	cout << "Algo Diffie Hellman" << endl;
	long g;	
	long p;
	while(pgcd(g,p) != 1)
	{
		g = rand()%200000;
		p = rand()%200000;
	}
	
	cout << "g  : " << g << endl;
	cout << "p  : " << p << endl;
	
	long a = rand()%200000;
	long b = rand()%200000;
	
	cout << "a  : " << a << endl;
	cout << "b  : " << b << endl;
	
	long ca = puissance(g, a, p);
	long cb = puissance(g, b, p);
	
	cout << "ca : " << ca << endl;
	cout << "cb : " << cb << endl;
	
	long cab = puissance(ca, b, p);
	long cba = puissance(cb, a, p);
	
	cout << "k  : " << cab << endl;
	cout << "k  : " << cba << endl;
}

int main(int argc, char * argv[])
{
	srand(time(NULL));
	if(argc != 2)
	{
		cout << "usage : " << argv[0] << " <entier>" <<endl;
		exit(1);
	}
	long m = atoi(argv[1]);
	long p, q, n;

	do
	{
		p = rand()%20000;
	}
	while(!rabin(2,p) && !rabin(3,p) && !rabin(5,p) && !rabin(7,p) && !rabin(13,p) && !rabin(17,p));

	do
	{
		q = rand()%20000;
	}
	while(!rabin(2,q) && !rabin(3,q) && !rabin(5,q) && !rabin(7,q) && !rabin(13,q) && !rabin(17,q));
	
	n = p * q;
	
	if(n < m)
	{
		cout << "nombre entré est superieur à n " <<endl;
		exit(1);
	}
	
	cout << "p : " << p << endl;
	cout << "q : " << q << endl;
	cout << "n : " << n << endl;
	
	long phiN = phi(p, q);
	long e;
	long random;
	
	do
	{
		random = rand() % phiN;
	}
	while(pgcd(phiN, random) != 1);
	
	cout << "random : " << random << endl;
	e = random;
	
	long u = bezout(e, phiN);
	long d;
	
	if(u>0)
		d = u;
	else
		d = phiN + u;
	
	cout << "d  : " << d << endl;
	// crypter
	long c = puissance(m, e, n); //  a ** e (mod n)
	cout << "Message Crypté   : " << c << endl;
	// decrypter
	int md = puissance(c, d, n);
	cout << "Message Décrypté : " << md << endl << endl;
	
	diffieHellman();
	
	return 0;
}
