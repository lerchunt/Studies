#################################################################################################
# Guillaume POUILLOUX - S4p2b - DUT Informatique - IUT Bordeaux 1								#
#																				  				#
# S4_Crypto - Implementation du cryptosysteme RSA												#
#																				  				#
#################################################################################################


import random
import util

def main():
	# On se donne le message a chiffre m=100
	m = 100
	limit = 1000000000000
	print "On utilise le message clair : %d" % m
	print "Generation de p et q premiers.."
	p = random.randint(1, limit)
	q = random.randint(1, limit)
	while (not (util.is_prime(p) and util.is_prime(q))):
		print p,q
		if(not util.is_prime(p)):
			p += 1
		if(not util.is_prime(q)):
			q += 1
		
		
	print "On a trouve p=%d et q=%d" % (p,q)
	n = p*q
	fi_n = (p-1)*(q-1)
	
	print "Generation de e premier avec fi_n"
	e = random.randint(1, fi_n)
	while (util.bezout(e, fi_n)[0] != 1):
		e = random.randint(1, fi_n)
	print "On a trouve e=%d" % e
	
	res = util.bezout(e, fi_n)
	while(res[1] <= 1 or res[1] >= fi_n):
		print "d=%d n'est pas entre 1 et fi_n donc regeneration de e.." % res[1]
		e = random.randint(1, fi_n)
		while (util.bezout(e, fi_n)[0] != 1):
			e = random.randint(1, fi_n)
		print "On a trouve e=%d" % e
		res = util.bezout(e, fi_n)
		
	d = res[1]
	print "La cle privee d vaut: %d" % d
	
	# Calculons l'exponentiation modulaire c=(m**e)%n
	c = util.lpowmod(m, e, n)
	print "Le message chiffre de %d vaut %d" % (m,c)
	
	# Calculons l'exponentiation modulaire clair=(c**d)%n
	clair = util.lpowmod(c, d, n)
	print "Le message en clair de %d vaut %d - verification ligne au dessus!" % (c,clair)
	
	m_prim = 133
	print "Le message chiffre %d a comme message clair %d" % (m_prim, util.lpowmod(m_prim, d, n))
	
if __name__ == '__main__':
    main()
