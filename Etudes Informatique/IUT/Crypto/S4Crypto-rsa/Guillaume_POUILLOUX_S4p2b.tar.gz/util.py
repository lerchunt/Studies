#################################################################################################
# Guillaume POUILLOUX - S4p2b - DUT Informatique - IUT Bordeaux 1								#
#																				  				#
# S4_Crypto - Fonctions utiles pour RSA et Diffie Hellman										#
#																				  				#
#################################################################################################

import re
import util
from math import ceil

# verifier si un nombre est premier
def is_prime(number):
	if number<=1 or number%2==0:
		return 0
	check=3  
	maxneeded=number
	while check<maxneeded+1:
		maxneeded=number/check
		if number%check==0:
			return 0
		check+=2
	return 1	

# exponentiation modulaire de x^y par n
def lpowmod(x, y, n):
    """puissance modulaire: (x**y)%n avec x, y et n entiers"""
    result = 1
    while y>0:
        if y&1>0:
            result = (result*x)%n
        y >>= 1
        x = (x*x)%n    
    return result

#affiche le pgcd et les entiers de Bezout correspondant
def bezout (a,b):
    r0=a
    r1=b
    u0=0
    u1=1
    v0=1
    v1=-(r0/r1)
    s=[r1,u0,v0]
    while r0%r1:
        r=r0
        r0=r1
        r1=r%r1
        u=u0
        v=v0
        u0=u1
        v0=v1
        q=r0/r1
        u1= u-q*u1
        v1=v-q*v1
        s=[r1,u0,v0]
    return s
