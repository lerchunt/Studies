#################################################################################################
# Guillaume POUILLOUX - S4p2b - DUT Informatique - IUT Bordeaux 1								#
#																				  				#
# S4_Crypto - Implementation du cryptosysteme base sur Diffie Hellman							#
#																				  				#
#################################################################################################

import random
import util

def main():
	limit = 100000000000000
	print "Generation de p premier"
	p = random.randint(1, limit)
	while (not util.is_prime(p)):
		print p
		p +=1
	print "On a trouve p=%d premier" % p

	g = random.randint(-p, p)
	while (g==0 or util.bezout(g,p)[0] != 1):
		g = random.randint(-p, p)
	print "On a trouve g=%d" % g
	
	a = input("Joueur1>> Choisissez a:")
	g_a = util.lpowmod(g, a, p)
	
	b = input("Joueur2>> Choisissez b:")
	g_b = util.lpowmod(g, b, p)
	
	print "Joueur 1 et Joueur 2 s'echangent respectivement (g**a mod p)=%d et (g**b mod p)=%d" % (g_a, g_b)
	
	print "Verification g_a**b%p == g_b**a%p"
	g_a_b = util.lpowmod(g_a, b, p)
	g_b_a = util.lpowmod(g_b, a, p)
	
	print "g_a**b mod p = %d" % g_a_b
	print "g_b**a mod p = %d" % g_b_a
	
	if(g_a_b == g_b_a):
		print "La cle de chiffrement est :%d" % g_a_b
	
if __name__ == '__main__':
    main()
