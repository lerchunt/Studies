#include <iostream>
#include <math.h>

using namespace std;

int Bezout(int rkm2,int rkm1,int ukm1=0,int vkm1=1,int ukm2=1,int vkm2=0)
{
    int rk=rkm2%rkm1;
    int qk=(rkm2-rk)/rkm1;
    if(rk==0)
    {
        //cout<<rkm1<<"=a*"<<ukm1<<"+b*"<<vkm1<<endl;
        return rkm1;
    }
    else
    {
         Bezout(rkm1,rk,ukm2-qk*ukm1,vkm2-qk*vkm1,ukm1,vkm1);
    }
}

int nbPremier(int nb)
{
    int i, compter, test,limite;
    test = compter = 0;

    limite = sqrt(nb) + 1;

    if (nb % 2 == 0)
        test = 1;
    else
    {
        for (i = 3 ; i < limite && ! test; i+=2, compter++)
            if (nb % i == 0)
                test = 1;
    }
    if (!test)
          return nb;
    else
          return nbPremier(nb+1);
}

int expMod(int m, int e, int n)
{
   int result = 1;

   while (e > 0)
   {
       if (e & 1 > 0) result = (result * m) % n;
      e >>= 1;
      m = (m * m) % n;
   }

   return result;
}

int main()
{
    int p, g, nombreP1, nombreP2, nombre1 = 0, nombre2 = 0;

    cout << "Rechercher un nombre premier pour A a partir de : "; cin >> nombre1;
    p = nbPremier(nombre1);
    cout << "Nombre premier : " << p << endl;

    cout << "Rechercher un nombre premier pour B a partir de : "; cin >> nombre2;
    g = nbPremier(nombre2);
    cout << "Nombre premier : " << g << endl;

    cout << "p : " << p << endl;
    cout << "g : " << g << endl;

    int a;
    cout << "Nb a : "; cin >> a;

    int b;
    cout << "Nb b : "; cin >> b;

    int ga = expMod(g, a, p);
    int gb = expMod(g, b, p);

    cout << "ga = " << ga << " - gb = " << gb << endl;

    int gab = expMod(ga, b, p);
    int gba = expMod(gb, a, p);

    cout << "gab = " << gab << " - gba = " << gba << endl;

    if(gab != gba)
        cout << "Erreur, gba != gab..." << endl;
    else
        cout << "La clef est : " << gab << endl;

}
