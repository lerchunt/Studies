#include <iostream>

using namespace std;

int Bezout(int rkm2,int rkm1,int ukm1=0,int vkm1=1,int ukm2=1,int vkm2=0)
{
    int rk=rkm2%rkm1;
    int qk=(rkm2-rk)/rkm1;
    if(rk==0)
    {
        //cout<<rkm1<<"=a*"<<ukm1<<"+b*"<<vkm1<<endl;
        return ukm1;
    }
    else
    {
         Bezout(rkm1,rk,ukm2-qk*ukm1,vkm2-qk*vkm1,ukm1,vkm1);
    }
}

int fiN(int p, int q)
{
    return (p-1)*(q-1);
}

int n(int p, int q)
{
    return p*q;
}

int expMod(int m, int e, int n)
{
   int result = 1;

   while (e > 0)
   {
       if (e & 1 > 0) result = (result * m) % n;
      e >>= 1;
      m = (m * m) % n;
   }

   return result;
}

int chiffrement(int m, int e, int n)
{
    return expMod(m,e,n);
}

int dechiffrement(int c, int d, int n)
{
    return expMod(c,d,n);
}





/* MAIN */


int main(int argc,char* argv[])
{
    if(argc<2)
    {
        cout<<"Usage: "<<argv[0]<<" <c/d>"<<endl;
        return -1;
    }
    char* mode = argv[1];

    /* INITIALISATIONS */
    int a,b,m;
    int val_n, e, val_fiN;
    int d, ch, dch;

    /* VALS DEMANDEES */
    cout<<"p=";cin>>a;
    cout<<"q=";cin>>b;
    cout<<"e=";cin>>e;

    val_n = n(a, b);
    val_fiN = fiN(a, b);
    d = Bezout(e, val_fiN);

    if(d < 0)
        d = val_fiN + d;


    /* Chiffrage */
    if(*mode == 'c')
    {
        cout << "Message a chiffrer : "; cin >> m;
        ch = chiffrement(m, e, val_n);
        cout << "Chiffrage = " << ch << endl;
    }

    /* D�chiffrage */
    if(*mode == 'd')
    {
        cout << "Message a dechiffrer = "; cin >> ch;
        dch = dechiffrement(ch, d, val_n);
        cout << "Dechiffage = " << dch << endl;
    }


    /* Affichages */
    /*
    cout << "p = " << a << " et q = " << b << endl;
    cout << "n = " << val_n << " et FI(n) = " << val_fiN << endl;
    cout << "D = " << d << endl;
    */

    return 0;
}
