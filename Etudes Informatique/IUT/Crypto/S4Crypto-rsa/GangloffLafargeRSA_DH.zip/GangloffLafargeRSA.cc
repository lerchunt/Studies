#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <time.h>
using namespace std;

long u=0;
long v=0;
long d=0;

long calculN(long p,long q)
{
    return p*q;
}

long phi(long p, long q)
{
    return (p-1)*(q-1);
}

long expModulaire(long b, long e, long n)
{
    long s=1;
    for(long i=0; i<e; i++)
    {
        s*=b;
        s=s%n;
    }
    return s;
}

long puissance (long a, long e, long n) {
    long p;

    for (p = 1; e > 0; e = e / 2) {
        if (e % 2 != 0)
            p = (p * a) % n;
        a = (a * a) % n;
    }
    return p;
}

long bezout(long a, long b)
{
    long b0=b;
    long p = 1;
    long q = 0;
    long r = 0;
    long s = 1;
    long nouveau_r;
    long nouveau_s;
    long quotient;
    long c;

    while (b != 0) {
        c = a % b;
        quotient = a/b;
        a = b;
        b = c;
        nouveau_r = p - quotient * r;
        nouveau_s = q - quotient * s;
        p = r;
        q = s;
        r = nouveau_r;
        s = nouveau_s;
    }
    if(p<0)
        return (p+b0);
    else
        return p;

}

long generatePremier()
{

    long n;
    bool prime = false;
    long test[7] = {2,3,5,7,11,13,19};
    while(!prime)
    {
        prime=true;
        n=rand()%10000;
        n=(n%2) ? n: n+1;
        for(long i= 0; i<7 && prime; i++) {

            prime =(puissance(test[i],n,n)%n) == test[i];
        }
    }

    return n;
}

long chiffrer(long m,long e,long n)
{
    long c;

    c=puissance(m,e,n);
    return c;

}
unsigned long pgcd(unsigned long a, unsigned long b)
{
    return b ? pgcd(b,a%b):a;
}

long dechiffrer(long c,long d,long n)
{
    long m;
    m=puissance(c,d,n);
    return m;
}

long calculD(long e,long phi)
{
    long d;
    d=bezout(e,phi);
    return d;

}

long calculE(long phiN)
{
    long e;
    bool premier= false;
    while(!premier)
    {
        e=rand()%phiN;
        if(pgcd(e,phiN)==1)
            premier=true;
    }

    return e;
}

int main(int argc,char** argv) {
	
    srand(time(NULL));
    long m=252;
    long p=generatePremier();
    long q=generatePremier();
    long n=calculN(p,q);
    long phiN=phi(p,q);
    long e=calculE(phiN);
    long d=bezout(e,phiN);
    long c= chiffrer(m,e,n);
    long dc=dechiffrer(c,d,n);

	cout << "Message d'origine : " << m << endl;
    cout<<"Valeur M : "<< m << " Valeur n : "<< n<< endl;
    cout << "Valeur c : "<< c<<endl;
    cout << "Message dechiffré : " <<dc<<endl;

    return 0;
}
