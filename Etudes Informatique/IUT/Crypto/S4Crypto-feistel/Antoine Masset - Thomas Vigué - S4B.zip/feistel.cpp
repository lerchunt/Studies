/* Binome :
 *  - Antoine Masset
 *  - Thomas Vigu�
 *
 * commande de compilation : 
 * g++ -c feistel.cpp
 * g++ -o feistel feistel.o 
 *
 * ex�cution
 * ./feistel feistel1.txt 10010110101101010111100001101101
 */
//======================================================================
#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <iomanip>

using namespace std;

int main(int argc,char** argv) {
  
  ifstream fichier;
  string cle;

  bool l[32];
  bool r[32];
  bool tempR[32];
  bool cleBool[32];

  if(argc<3) {
    cout<<"Usage: "<<argv[0]<<" <fichier> <cle (chaine de caracteres minuscules)>"<<endl;
    return -1;
  }

  //R�cup�re les arguments
  fichier.open(argv[1],ios::in);
  if(fichier.bad()) {
    cout << "Impossible d'ouvrir "<<argv[1]<<endl;
    return -1;
  }
  
	
  cle=argv[2];
  int taille_cle = cle.size();
  
  //verification de la taille de la cle
  if(taille_cle != 32) {
    cout << "cle != a 32 bits "<<argv[1]<<endl;
    return -1;
  }
  
  //transformation de la chaine string en tableau de booleens pour la cle
  for(std::string::size_type i = 0; i < cle.length(); ++i)
  {
	  if(cle[i] == '0')
		cleBool[i] = 0;
	  if(cle[i] == '1')
		cleBool[i] = 1;
  }
  
  cout <<  setw(22) << "cle : "; 
  for(int i = 0; i < 32; ++i)
	cout  << cleBool[i];
  cout << endl;
    
  
  cout <<  setw(22) << "message : "; 
  
  //Position dans le fichier
  int position=0;
  //Lit le fichier caract�re par caract�re
  while(true) {
	char lettreLue;
	
    //Lit un caractere du fichier
    fichier >> lettreLue;
    
    //Fin de fichier ?
    if(fichier.eof()) {
      break;
    }
    
    //cr�ation du tableau block gauche
    if(position < 32) {
		if(lettreLue == '0')
			l[position] = 0;
		if(lettreLue == '1')
			l[position] = 1;
    }
    
    //cr�ation du tableau block droit
    else {
		if(lettreLue == '0')
			r[position-32] = 0;
		if(lettreLue == '1')
			r[position-32] = 1;
    }
    
    cout << lettreLue; 
    
    position++;
  }
  
  cout << endl;
  
  //affichage des blocks
  cout << setw(22) << "block left : "; 
  for(int i = 0; i < 32; ++i)
	cout << l[i];
  cout << endl << setw(22) << "block right : ";
 
  for(int i = 0; i < 32; ++i)
	cout << r[i];
  cout << endl;
  
  //boucle de cryptage
  for(int i = 0; i < 12; ++i) // i = nombre de rondes
  {
	for(int j = 0; j < 32; ++j)
	  tempR[j] = r[j];         // cr�ation d'un tableau temporaire pour les transitions de blocks
	for(int j = 0; j < 32; ++j)
	{
	  r[j] = r[j] ^ cleBool[j]; // XOR du block de droite avec la cl�
	  r[j] = l[j] ^ r[j];       // XOR du block de droite crypt� avec le block de gauche
	}
	for(int j = 0; j < 32; ++j)
	  l[j] = tempR[j];
  }
  
  //affichage des r�sultats
  cout << setw(22) << "block left chiffre : "; 
  for(int i = 0; i < 32; ++i)
	cout << l[i];
	
  cout << endl << setw(22) << "block right chiffre : ";
  for(int i = 0; i < 32; ++i)
	cout << r[i];
  cout << endl;
  
  cout <<  setw(22) << "message chiffre : ";
  for(int i = 0; i < 32; ++i)
	cout << l[i];
  for(int i = 0; i < 32; ++i)
	cout << r[i];
  cout << endl;
  
  return 0;
}
