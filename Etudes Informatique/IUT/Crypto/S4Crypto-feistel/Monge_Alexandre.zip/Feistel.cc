#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>

const int LONGUEUR_BLOC = 64;
const int LONGUEUR_DEMI_BLOC = 32;
const int LONGUEUR_CLEF = 32;
const int RONDES = 10;

using namespace std;

void newKeyC(bool* key)      // Key = Key + 1
{
    for(int i = LONGUEUR_DEMI_BLOC - 1; i > -1; i--)
    {

        if(key[i] == 0)
        {
             key[i] = 1;
             break;
        }
        else
        {
            key[i] = 0;
        }
    }
}

void newKeyD(bool* key)      // Key = Key + 1
{
    for(int i = LONGUEUR_DEMI_BLOC - 1; i > -1; i--)
    {

        if(key[i] == 0)
        {
             key[i] = 1;
        }
        else
        {
            key[i] = 0;
            break;
        }
    }
}


/* -------- MAIN -------- */
int main(int argc,char** argv)
{
    ifstream fichier;
    ifstream fichier2;

    bool texte[LONGUEUR_BLOC];
    bool texteCrypte[LONGUEUR_BLOC];
    bool texteD[LONGUEUR_DEMI_BLOC];
    bool texteDTmp[LONGUEUR_DEMI_BLOC];
    bool texteG[LONGUEUR_DEMI_BLOC];
    bool texteGTmp[LONGUEUR_DEMI_BLOC];
    bool key[LONGUEUR_CLEF];


    if(argc<4)
    {
        cout<<"Usage: "<<argv[0]<<" <fichier_texte> <fichier_key> <c/d>"<<endl;
        return -1;
    }

    //////////////////////////////////////////////////////////////
    fichier.open(argv[1],ios::in);
    if(fichier.bad())
    {
        cout << "Impossible d'ouvrir "<<argv[1]<<endl;
        return -1;
    }

    fichier2.open(argv[2],ios::in);
    if(fichier.bad())
    {
        cout << "Impossible d'ouvrir "<<argv[1]<<endl;
        return -1;
    }
    //////////////////////////////////////////////////////////////

    char* mode = argv[3];

    /* ----------------------- INITIALISATION ----------------------- */
    int index = 0;

    while(true)
    {
        char caractere;

        fichier >> caractere;

        if(caractere == '0')
            texte[index] = 0;
        else
            texte[index] = 1;
        index++;

        if(fichier.eof())
        {
            break;
        }
    }

    index = 0;
    while(true)
    {
        char caractere;

        fichier2 >> caractere;

        if(caractere == '0')
            key[index] = 0;
        else
            key[index] = 1;
        index++;

        if(fichier2.eof())
        {
            break;
        }
    }


    cout << "Texte   : ";
    for(int i = 0; i < LONGUEUR_BLOC; i++)
        cout << texte[i];
    cout << endl;

    cout << "Key     : ";
    for(int i = 0; i < LONGUEUR_DEMI_BLOC; i++)
        cout << key[i];
    cout << endl << endl;

    for(int i = 0; i < LONGUEUR_DEMI_BLOC; i++)
        texteG[i] = texte[i];

    for(int i = 0; i < LONGUEUR_DEMI_BLOC; i++)
        texteD[i] = texte[LONGUEUR_DEMI_BLOC + i];

    /* -------------------------------------------------------------- */



    /* -------------------------- CRYPTAGE -------------------------- */
    if(*mode == 'c')
    {
        cout << "Debut cryptage" << endl;
       for(int r = 0; r < RONDES; r++) // Pour chaque ronde
        {
            if(r < RONDES - 1)
             {
                newKeyC(key);
                cout << "New Key : ";
                for(int i=0; i < LONGUEUR_DEMI_BLOC; i++)
                    cout << key[i];
                cout << endl;



                for(int i = 0; i < LONGUEUR_DEMI_BLOC; i++)
                    texteGTmp[i] = texteG[i];

                for(int i = 0; i < LONGUEUR_DEMI_BLOC; i++)
                    texteDTmp[i] = texteD[i];

                for(int i = 0; i < LONGUEUR_DEMI_BLOC; i++)
                    texteG[i] = texteD[i];

                for(int i = 0; i < LONGUEUR_DEMI_BLOC; i++)
                    texteDTmp[i] = ((texteD[i] && !key[i]) || (!texteD[i] && key[i]));

                for(int i = 0; i < LONGUEUR_DEMI_BLOC; i++)
                    texteD[i] = ((texteDTmp[i] && !texteGTmp[i]) || (!texteDTmp[i] && texteGTmp[i]));

                for(int i = 0; i < LONGUEUR_DEMI_BLOC; i++)
                    texteCrypte[i] = texteG[i];
                for(int i = 0; i < LONGUEUR_DEMI_BLOC; i++)
                    texteCrypte[LONGUEUR_DEMI_BLOC + i] = texteD[i];

                cout << "Texte   : ";
                for(int i = 0; i < LONGUEUR_BLOC; i++)
                    cout << texteCrypte[i];
                cout << endl;
             }
        }
    }
    /* -------------------------------------------------------------- */

    /* ------------------------- DECRYPTAGE ------------------------- */
    if(*mode == 'd')
    {
        cout << "Debut decryptage" << endl;
        for(int r = 0; r < RONDES; r++) // Pour chaque ronde
        {
             if(r < RONDES - 1)
             {
                newKeyC(key);
                cout << "New Key : ";
                for(int i=0; i < LONGUEUR_DEMI_BLOC; i++)
                    cout << key[i];
                cout << endl;



                for(int i = 0; i < LONGUEUR_DEMI_BLOC; i++)
                    texteGTmp[i] = texteG[i];

                for(int i = 0; i < LONGUEUR_DEMI_BLOC; i++)
                    texteDTmp[i] = texteD[i];

                for(int i = 0; i < LONGUEUR_DEMI_BLOC; i++)
                    texteG[i] = texteD[i];

                for(int i = 0; i < LONGUEUR_DEMI_BLOC; i++)
                    texteDTmp[i] = ((texteD[i] && !key[i]) || (!texteD[i] && key[i]));

                for(int i = 0; i < LONGUEUR_DEMI_BLOC; i++)
                    texteD[i] = ((texteDTmp[i] && !texteGTmp[i]) || (!texteDTmp[i] && texteGTmp[i]));

                for(int i = 0; i < LONGUEUR_DEMI_BLOC; i++)
                    texteCrypte[i] = texteG[i];
                for(int i = 0; i < LONGUEUR_DEMI_BLOC; i++)
                    texteCrypte[LONGUEUR_DEMI_BLOC + i] = texteD[i];
                    
                cout << "Texte   : ";
                for(int i = 0; i < LONGUEUR_BLOC; i++)
                    cout << texteCrypte[i];
                cout << endl;
             }
        }
    }

    /* -------------------------------------------------------------- */
    return EXIT_SUCCESS;
}
